# Xerophy Framework
The lightweight framework for php developers
- [Routing system](https://xerophy.com).
- [Twig Template Engine](https://twig.symfony.com/).
- [Database management](https://xerophy.com).


### Xerophy documentation
[Documentation](https://xerophy.com/documentation).
