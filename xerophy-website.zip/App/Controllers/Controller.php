<?php

namespace App\Controllers;
use Xerophy\Framework\Routing\Controller as baseController;

class Controller extends baseController
{

}