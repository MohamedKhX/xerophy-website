<?php

namespace App\Models;

use \Xerophy\Framework\Database\Model as BaseModel;

class Model extends BaseModel
{

}